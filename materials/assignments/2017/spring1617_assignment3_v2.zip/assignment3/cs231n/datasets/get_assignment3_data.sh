#!/bin/bash
./get_coco_captioning.sh
./get_squeezenet_tf.sh
./get_imagenet_val.sh

